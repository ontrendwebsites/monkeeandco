<?php 
/**
 * Plugin Name: Ontrend websites Custom Functions
 * Description: This plugin contains all of my awesome custom functions.
 * Author: Andrew McDougal
 * Version: 0.1 */ 
/* Your code goes below here. */ 

/* Your code goes above here. */ ?>